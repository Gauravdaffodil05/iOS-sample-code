# iOS exercise | Daffodil

Build an iOS app that:

- Pulls data of capsules launched since 2014 from the Open APIs provided by [SpaceX](https://github.com/r-spacex/SpaceX-API) and lists out the *top 5* (based on number of landings)

- It should also be able to display basic information (as per below) of each of these capsules: 
`Original date of launch, number of landings, Type, missions, details, status`

- When I tap on the “type” of any of these capsules, I should be able to see basic information `first flight, mass in kg, name, crew capacity and number of thrusters` of that type of capsule.

###### Other Instructions 
While you're not expected to build an app that resembles a high-fidelity design, please make sure the app is functional and also has appropriate UI elements in place. Don't worry about colors etc too much as it is code quality and various choices you make in the process that matter most. 
Please work independently of each other, make regular commits, spill coffee on your keyboards and try to be in a different room from your business consultants

Code this out as you would for a startup that you're investing in, yourself :) 


Solution:

Exercise has been completed using MVP architecture in swift. Best practices have been followed to make the project easy to understand, debug and test.

