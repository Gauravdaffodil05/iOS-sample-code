// Common Error Codes

import Foundation

enum ErrorCodes:String {
    
    //MARK: Common
    
    //TODO: Sample Error
    case INVALID_AUTH = "INVALID_AUTH"
    
    //LOGIN
    case INVALID_CREDENTIAL = "401"
    
    
    
}

