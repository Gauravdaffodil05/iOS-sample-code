
//Note :- This class contains CapsuleDetail Buisness Logic

class CapsuleDetailBusinessLogic {
    
    
    deinit {
        print("CapsuleDetailBusinessLogic deinit")
    }

    /**
     This method is used for perform CapsuleDetail With Valid Inputs constructed into a CapsuleDetailRequestModel
     
     - parameter inputData: Contains info for CapsuleDetail
     - parameter success:   Returning Success Response of API
     - parameter failure:   NSError Response Contaons ErrorInfo
     */
    func performCapsuleDetail(withCapsuleDetailRequestModel CapsuleDetailRequestModel: CapsuleDetailRequestModel, presenterDelegate:ResponseCallback) ->Void {
        
        //Adding predefined set of errors
        let errorResolver:ErrorResolver = ErrorResolver.registerErrorsForApiRequests() //self.registerErrorForCapsuleDetail()
        CapsuleDetailApiRequest().makeAPIRequest(withReqFormData: CapsuleDetailRequestModel, errorResolver: errorResolver, responseCallback: presenterDelegate)
    }
    
    
    /**
     This method is used for adding set of Predefined Error coming from server
     */
    private func registerErrorForCapsuleDetail() ->ErrorResolver{
        
        let errorResolver:ErrorResolver = ErrorResolver.registerErrorsForApiRequests() //ErrorResolver()
        
        return errorResolver
    }
}
