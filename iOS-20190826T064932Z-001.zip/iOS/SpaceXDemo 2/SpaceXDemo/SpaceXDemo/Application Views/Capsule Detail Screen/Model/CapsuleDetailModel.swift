

import Foundation

struct CapsuleDetailModel : Codable {
	let id : String?
	let name : String?
	let type : String?
	let active : Bool?
	let crew_capacity : Int?
	let sidewall_angle_deg : Int?
	let orbit_duration_yr : Int?
	let dry_mass_kg : Int?
	let dry_mass_lb : Int?
	let first_flight : String?
	let heat_shield : Heat_shield?
	let thrusters : [Thrusters]?
	let launch_payload_mass : Launch_payload_mass?
	let launch_payload_vol : Launch_payload_vol?
	let return_payload_mass : Return_payload_mass?
	let return_payload_vol : Return_payload_vol?
	let pressurized_capsule : Pressurized_capsule?
	let trunk : Trunk?
	let height_w_trunk : Height_w_trunk?
	let diameter : Diameter?
	let flickr_images : [String]?
	let wikipedia : String?
	let description : String?

	enum CodingKeys: String, CodingKey {

		case id = "id"
		case name = "name"
		case type = "type"
		case active = "active"
		case crew_capacity = "crew_capacity"
		case sidewall_angle_deg = "sidewall_angle_deg"
		case orbit_duration_yr = "orbit_duration_yr"
		case dry_mass_kg = "dry_mass_kg"
		case dry_mass_lb = "dry_mass_lb"
		case first_flight = "first_flight"
		case heat_shield = "heat_shield"
		case thrusters = "thrusters"
		case launch_payload_mass = "launch_payload_mass"
		case launch_payload_vol = "launch_payload_vol"
		case return_payload_mass = "return_payload_mass"
		case return_payload_vol = "return_payload_vol"
		case pressurized_capsule = "pressurized_capsule"
		case trunk = "trunk"
		case height_w_trunk = "height_w_trunk"
		case diameter = "diameter"
		case flickr_images = "flickr_images"
		case wikipedia = "wikipedia"
		case description = "description"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		id = try values.decodeIfPresent(String.self, forKey: .id)
		name = try values.decodeIfPresent(String.self, forKey: .name)
		type = try values.decodeIfPresent(String.self, forKey: .type)
		active = try values.decodeIfPresent(Bool.self, forKey: .active)
		crew_capacity = try values.decodeIfPresent(Int.self, forKey: .crew_capacity)
		sidewall_angle_deg = try values.decodeIfPresent(Int.self, forKey: .sidewall_angle_deg)
		orbit_duration_yr = try values.decodeIfPresent(Int.self, forKey: .orbit_duration_yr)
		dry_mass_kg = try values.decodeIfPresent(Int.self, forKey: .dry_mass_kg)
		dry_mass_lb = try values.decodeIfPresent(Int.self, forKey: .dry_mass_lb)
		first_flight = try values.decodeIfPresent(String.self, forKey: .first_flight)
		heat_shield = try values.decodeIfPresent(Heat_shield.self, forKey: .heat_shield)
		thrusters = try values.decodeIfPresent([Thrusters].self, forKey: .thrusters)
		launch_payload_mass = try values.decodeIfPresent(Launch_payload_mass.self, forKey: .launch_payload_mass)
		launch_payload_vol = try values.decodeIfPresent(Launch_payload_vol.self, forKey: .launch_payload_vol)
		return_payload_mass = try values.decodeIfPresent(Return_payload_mass.self, forKey: .return_payload_mass)
		return_payload_vol = try values.decodeIfPresent(Return_payload_vol.self, forKey: .return_payload_vol)
		pressurized_capsule = try values.decodeIfPresent(Pressurized_capsule.self, forKey: .pressurized_capsule)
		trunk = try values.decodeIfPresent(Trunk.self, forKey: .trunk)
		height_w_trunk = try values.decodeIfPresent(Height_w_trunk.self, forKey: .height_w_trunk)
		diameter = try values.decodeIfPresent(Diameter.self, forKey: .diameter)
		flickr_images = try values.decodeIfPresent([String].self, forKey: .flickr_images)
		wikipedia = try values.decodeIfPresent(String.self, forKey: .wikipedia)
		description = try values.decodeIfPresent(String.self, forKey: .description)
	}

}
