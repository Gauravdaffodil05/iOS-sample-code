

import Foundation
struct Cargo : Codable {
	let solar_array : Int?
	let unpressurized_cargo : Bool?

	enum CodingKeys: String, CodingKey {

		case solar_array = "solar_array"
		case unpressurized_cargo = "unpressurized_cargo"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		solar_array = try values.decodeIfPresent(Int.self, forKey: .solar_array)
		unpressurized_cargo = try values.decodeIfPresent(Bool.self, forKey: .unpressurized_cargo)
	}

}
