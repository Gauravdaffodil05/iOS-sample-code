

import Foundation
struct Heat_shield : Codable {
	let material : String?
	let size_meters : Double?
	let temp_degrees : Int?
	let dev_partner : String?

	enum CodingKeys: String, CodingKey {

		case material = "material"
		case size_meters = "size_meters"
		case temp_degrees = "temp_degrees"
		case dev_partner = "dev_partner"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		material = try values.decodeIfPresent(String.self, forKey: .material)
		size_meters = try values.decodeIfPresent(Double.self, forKey: .size_meters)
		temp_degrees = try values.decodeIfPresent(Int.self, forKey: .temp_degrees)
		dev_partner = try values.decodeIfPresent(String.self, forKey: .dev_partner)
	}

}
