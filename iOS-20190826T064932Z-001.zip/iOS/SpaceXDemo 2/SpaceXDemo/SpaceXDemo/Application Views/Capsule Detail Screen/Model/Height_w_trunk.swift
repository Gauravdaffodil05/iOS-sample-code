

import Foundation
struct Height_w_trunk : Codable {
	let meters : Double?
	let feet : Double?

	enum CodingKeys: String, CodingKey {

		case meters = "meters"
		case feet = "feet"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		meters = try values.decodeIfPresent(Double.self, forKey: .meters)
		feet = try values.decodeIfPresent(Double.self, forKey: .feet)
	}

}
