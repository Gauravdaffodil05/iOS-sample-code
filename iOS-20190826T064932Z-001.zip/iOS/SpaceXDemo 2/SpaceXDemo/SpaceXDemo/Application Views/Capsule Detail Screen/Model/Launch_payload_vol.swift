

import Foundation
struct Launch_payload_vol : Codable {
	let cubic_meters : Int?
	let cubic_feet : Int?

	enum CodingKeys: String, CodingKey {

		case cubic_meters = "cubic_meters"
		case cubic_feet = "cubic_feet"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		cubic_meters = try values.decodeIfPresent(Int.self, forKey: .cubic_meters)
		cubic_feet = try values.decodeIfPresent(Int.self, forKey: .cubic_feet)
	}

}
