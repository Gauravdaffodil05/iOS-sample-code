

import Foundation
struct Pressurized_capsule : Codable {
	let payload_volume : Payload_volume?

	enum CodingKeys: String, CodingKey {

		case payload_volume = "payload_volume"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		payload_volume = try values.decodeIfPresent(Payload_volume.self, forKey: .payload_volume)
	}

}
