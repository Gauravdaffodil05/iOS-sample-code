

import Foundation
struct Return_payload_mass : Codable {
	let kg : Int?
	let lb : Int?

	enum CodingKeys: String, CodingKey {

		case kg = "kg"
		case lb = "lb"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		kg = try values.decodeIfPresent(Int.self, forKey: .kg)
		lb = try values.decodeIfPresent(Int.self, forKey: .lb)
	}

}
