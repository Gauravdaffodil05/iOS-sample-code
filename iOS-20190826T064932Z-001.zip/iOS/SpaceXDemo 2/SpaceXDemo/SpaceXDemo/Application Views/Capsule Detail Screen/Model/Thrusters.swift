

import Foundation
struct Thrusters : Codable {
	let type : String?
	let amount : Int?
	let pods : Int?
	let fuel_1 : String?
	let fuel_2 : String?
	let thrust : Thrust?

	enum CodingKeys: String, CodingKey {

		case type = "type"
		case amount = "amount"
		case pods = "pods"
		case fuel_1 = "fuel_1"
		case fuel_2 = "fuel_2"
		case thrust = "thrust"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		type = try values.decodeIfPresent(String.self, forKey: .type)
		amount = try values.decodeIfPresent(Int.self, forKey: .amount)
		pods = try values.decodeIfPresent(Int.self, forKey: .pods)
		fuel_1 = try values.decodeIfPresent(String.self, forKey: .fuel_1)
		fuel_2 = try values.decodeIfPresent(String.self, forKey: .fuel_2)
		thrust = try values.decodeIfPresent(Thrust.self, forKey: .thrust)
	}

}
