

import Foundation
struct Trunk : Codable {
	let trunk_volume : Trunk_volume?
	let cargo : Cargo?

	enum CodingKeys: String, CodingKey {

		case trunk_volume = "trunk_volume"
		case cargo = "cargo"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		trunk_volume = try values.decodeIfPresent(Trunk_volume.self, forKey: .trunk_volume)
		cargo = try values.decodeIfPresent(Cargo.self, forKey: .cargo)
	}

}
