
//Notes:- This class is used as presenter for CapsuleDetailViewPresenter

import Foundation

class CapsuleDetailViewPresenter: ResponseCallback{
    
//MARK:- CapsuleDetailViewPresenter local properties
    
    private weak var capsuleDetailViewDelegate          : CapsuleDetailViewDelegate?
    private lazy var capsuleDetailBusinessLogic         : CapsuleDetailBusinessLogic = CapsuleDetailBusinessLogic()

//MARK:- Constructor
    
    init(delegate responseDelegate:CapsuleDetailViewDelegate){
        self.capsuleDetailViewDelegate = responseDelegate
    }
    
//MARK:- ResponseCallback delegate methods
    
    func servicesManagerSuccessResponse<T:Codable>(responseObject : T){
        self.capsuleDetailViewDelegate?.didFetchedCapsuleDetail(data: responseObject as! CapsuleDetailModel)
        self.capsuleDetailViewDelegate?.hideLoader()
    }
    
    func servicesManagerError(error: ErrorModel){
        self.capsuleDetailViewDelegate?.showErrorAlert(error.getErrorTitle(), alertMessage: error.getErrorMessage())
        self.capsuleDetailViewDelegate?.hideLoader()
    }
    
//MARK:- Methods to make decision and call CapsuleDetail Api.
    
    func sendCapsuleDetailRequestWithId(id: String){
        self.capsuleDetailViewDelegate?.showLoader()
        
        let requestModel = CapsuleDetailRequestModel.Builder()
            .addRequestHeader(key:AppConstants.APIRequestHeaders.CONTENT_TYPE.rawValue, value: AppConstants.APIRequestHeaders.APPLICATION_JSON.rawValue)
            .addRequestQueryParams(key: "id", value: id as AnyObject)
            .build()
        
        self.capsuleDetailBusinessLogic.performCapsuleDetail(withCapsuleDetailRequestModel: requestModel, presenterDelegate: self)
    }
}
