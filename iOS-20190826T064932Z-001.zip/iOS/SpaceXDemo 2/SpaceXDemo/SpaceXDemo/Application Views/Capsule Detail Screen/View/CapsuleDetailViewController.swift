//This class is responsible for showing detail for the selected capsule

import UIKit

class CapsuleDetailViewController: BaseViewController {
    
    @IBOutlet weak var tblViewCapsuleDetail: UITableView!
    var capsuleDetailPresenter: CapsuleDetailViewPresenter!
    var dataSourceCapsule: CapsuleDetailModel?
    var capsuleId: String = ""
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblFirstFlight: UILabel!
    @IBOutlet weak var lblCrewCapacity: UILabel!
    @IBOutlet weak var lblMassInKg: UILabel!
    @IBOutlet weak var lblNoOfThrusters: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        capsuleDetailPresenter = CapsuleDetailViewPresenter(delegate: self)
        
        self.getCapsuleDetail()
    }
    
    override func viewDidAppear(_ animated: Bool) {
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /// This method is used to get capsule details
    func getCapsuleDetail(){
        capsuleDetailPresenter.sendCapsuleDetailRequestWithId(id: capsuleId)
    }
    
    
    /// This method is used to bind the data to the view
    func initScreen(){
        guard dataSourceCapsule != nil else {return}
        
        lblName.text = dataSourceCapsule?.name ?? ""
        lblFirstFlight.text = dataSourceCapsule?.first_flight ?? ""
        lblCrewCapacity.text = "\(dataSourceCapsule?.crew_capacity ?? 0)"
        lblMassInKg.text = "\(dataSourceCapsule?.dry_mass_kg ?? 0)"
        lblNoOfThrusters.text = "\(dataSourceCapsule?.thrusters?.count ?? 0)"
    }
}


// MARK: - CapsuleDetailViewDelegate
extension CapsuleDetailViewController: CapsuleDetailViewDelegate{
    
    func didFetchedCapsuleDetail(data: CapsuleDetailModel) {
        self.dataSourceCapsule = data
        self.initScreen()
    }
}
