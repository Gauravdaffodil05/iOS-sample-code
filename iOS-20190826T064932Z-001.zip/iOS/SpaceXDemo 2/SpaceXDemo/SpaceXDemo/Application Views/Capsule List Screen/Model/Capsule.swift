

import Foundation

struct Capsule: Codable  {
    
    var capsule_serial: String?
    var capsule_id: String?
    var status:String?
    var original_launch: String?
    var original_launch_unix: Int?
    var landings: Int?
    var type: String?
    var details: String?
    var reuse_count: Int?
    var missions: [Mission]?
    var isLaunchAfter2014: Bool = false

    private enum CodingKeys: String, CodingKey {
        case capsule_serial
        case capsule_id
        case status
        case original_launch
        case original_launch_unix
        case landings
        case type
        case details
        case reuse_count
        case missions
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        capsule_serial = try values.decodeIfPresent(String.self, forKey: .capsule_serial)
        capsule_id = try values.decodeIfPresent(String.self, forKey: .capsule_id)
        status = try values.decodeIfPresent(String.self, forKey: .status)
        original_launch = try values.decodeIfPresent(String.self, forKey: .original_launch)
        original_launch_unix = try values.decodeIfPresent(Int.self, forKey: .original_launch_unix)
        missions = try values.decodeIfPresent([Mission].self, forKey: .missions)
        landings = try values.decodeIfPresent(Int.self, forKey: .landings)
        type = try values.decodeIfPresent(String.self, forKey: .type)
        details = try values.decodeIfPresent(String.self, forKey: .details)
        reuse_count = try values.decodeIfPresent(Int.self, forKey: .reuse_count)
        isLaunchAfter2014 = original_launch != nil ? AppUtility.checkIfDateFallsAfterYear2014(dateStr: original_launch!) : false
    }
}
