

import Foundation

struct Mission: Codable  {
    
    var name: String?
    var flight: Int?

    private enum CodingKeys: String, CodingKey {
        case name
        case flight
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        flight = try values.decodeIfPresent(Int.self, forKey: .flight)
    }
}
