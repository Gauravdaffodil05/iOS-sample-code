
//Notes:- This class is used as presenter for CapsuleListViewPresenter

import Foundation

class CapsuleListViewPresenter: ResponseCallback{
    
//MARK:- CapsuleListViewPresenter local properties
    
    private weak var capsuleListViewDelegate          : CapsuleListViewDelegate?
    private lazy var capsuleListBusinessLogic         : CapsuleListBusinessLogic = CapsuleListBusinessLogic()

//MARK:- Constructor
    
    init(delegate responseDelegate:CapsuleListViewDelegate){
        self.capsuleListViewDelegate = responseDelegate
    }
    
//MARK:- ResponseCallback delegate methods
    
    func servicesManagerSuccessResponse<T:Codable>(responseObject : T){
        let response = responseObject as! [Capsule]
        let filteredResponse = response.filter { (capsule) -> Bool in
            return capsule.isLaunchAfter2014
        }
        
        self.capsuleListViewDelegate?.didFetchedCapsuleList(data: filteredResponse)
        self.capsuleListViewDelegate?.hideLoader()
    }
    
    func servicesManagerError(error: ErrorModel){
        self.capsuleListViewDelegate?.showErrorAlert(error.getErrorTitle(), alertMessage: error.getErrorMessage())
        self.capsuleListViewDelegate?.hideLoader()
    }
    
//MARK:- Methods to make decision and call CapsuleList Api.
    
    func sendCapsuleListRequest(){
        self.capsuleListViewDelegate?.showLoader()
        
        let requestModel = CapsuleListRequestModel.Builder()
            .addRequestHeader(key:AppConstants.APIRequestHeaders.CONTENT_TYPE.rawValue, value: AppConstants.APIRequestHeaders.APPLICATION_JSON.rawValue)
            .build()
        
        self.capsuleListBusinessLogic.performCapsuleList(withCapsuleListRequestModel: requestModel, presenterDelegate: self)
    }
}
