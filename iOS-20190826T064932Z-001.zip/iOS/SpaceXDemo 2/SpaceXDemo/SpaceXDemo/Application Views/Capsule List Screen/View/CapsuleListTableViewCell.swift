//This class is responsible for binding the capsule data

import UIKit

class CapsuleListTableViewCell: UITableViewCell {
    
    //MARK: IBOutlets
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblDateOfLaunch: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblNoOfLandings: UILabel!
    @IBOutlet weak var lblDetails: UILabel!
    @IBOutlet weak var lblMissions: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    /// This method is used to configure the cell
    ///
    /// - Parameter data: Capsule data
    func config(data: Capsule){
        lblType.text = data.type ?? "NA"
        lblDateOfLaunch.text = data.original_launch != nil ? AppUtility.getDateFromUTCFormat(dateStr: data.original_launch!) : "NA"
        lblStatus.text = data.status ?? "NA"
        lblNoOfLandings.text = "\(data.landings ?? 0)"
        lblDetails.text = data.details ?? "NA"
        lblMissions.text = self.getCommaSeperatedMissions(missions: data.missions)
    }
    
    
    /// This method returns comma seperated missions
    ///
    /// - Parameter missions: Array of missions
    /// - Returns: Comma seperated mission names
    private func getCommaSeperatedMissions(missions: [Mission]?)->String{
        var missionNameArr = [String]()

        guard missions != nil else {return "NA"}

        for mission in missions!{
            if let missionName = mission.name{
                missionNameArr.append(missionName)
            }
        }
        
        return  missionNameArr.joined(separator: ", ")
    }
}
