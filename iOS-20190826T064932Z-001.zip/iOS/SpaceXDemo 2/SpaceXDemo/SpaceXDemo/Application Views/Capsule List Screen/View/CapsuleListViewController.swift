//This screen is responsible for showing list of capsules

import UIKit

class CapsuleListViewController: BaseViewController {
    
    @IBOutlet weak var tblViewCapsuleList: UITableView!
    var capsuleListPresenter: CapsuleListViewPresenter!
    var dataSourceCapsule: [Capsule] = [] {
        didSet {
            self.tblViewCapsuleList.reloadData()
        }
    }
    
    /// MARK: View Controller life cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        capsuleListPresenter = CapsuleListViewPresenter(delegate: self)
        
        configTableView()
        
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { [weak self] (isFinished) in
            self?.getCapsuleList()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
    }
    
    
    /// This method is used to get list of capsules from api
    func getCapsuleList(){
        capsuleListPresenter.sendCapsuleListRequest()
    }
    
    /// This method is used to navigate to detail screen with capsule data
    ///
    /// - Parameter data: Selected Capsule Data Model
    func moveToDetailScreenWithData(data: Capsule){
        let vcDetail = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CapsuleDetailViewController") as! CapsuleDetailViewController
        vcDetail.capsuleId = data.capsule_id ?? ""
        self.navigationController?.pushViewController(vcDetail, animated: true)
    }
}


// MARK: - CapsuleListViewDelegate
extension CapsuleListViewController: CapsuleListViewDelegate{
    
    func didFetchedCapsuleList(data: [Capsule]) {
        self.dataSourceCapsule = data
    }
}


// MARK: - UITableViewDelegate, UITableViewDataSource
extension CapsuleListViewController: UITableViewDelegate, UITableViewDataSource{
    
    
    /// This method is used to configure the table view
    func configTableView(){
        self.tblViewCapsuleList.registerTableViewCell(tableViewCell: CapsuleListTableViewCell.self)
        self.tblViewCapsuleList.delegate = self
        self.tblViewCapsuleList.dataSource = self
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataSourceCapsule.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: CapsuleListTableViewCell = tableView.dequeueReusableCell(withIdentifier: "CapsuleListTableViewCell") as! CapsuleListTableViewCell
        cell.config(data: self.dataSourceCapsule[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.moveToDetailScreenWithData(data: self.dataSourceCapsule[indexPath.row])
    }
}
