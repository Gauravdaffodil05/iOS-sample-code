
//This extension handle navigation bar customizaton logic for the app

import UIKit

extension UIViewController {
    
    func addNavigationBackButton() ->Void{
        let buttonImage: UIImage = #imageLiteral(resourceName: "ic_back")
        let button: UIButton = UIButton(type: .custom)
        button.setImage(buttonImage, for: .normal)
        let barButtonItem: UIBarButtonItem = UIBarButtonItem(customView: button)
        button.addTarget(self, action: #selector(UIViewController.backButtonClick), for: .touchUpInside)
        self.navigationItem.leftBarButtonItem = barButtonItem
    }
    
    func setNavigationBarTitle(title: String)->Void{
        self.navigationItem.title = title
    }
    
    @objc func backButtonClick() ->Void {
        self.navigationController?.popViewController(animated: true)
    }
}
